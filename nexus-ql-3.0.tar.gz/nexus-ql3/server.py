#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
server.py — NEXUS QL v3 — serveur local http://localhost:3620
API : /api/status /api/rules /api/analyze /api/query
      /api/files /api/file /api/save
Zéro dépendance (http.server) · tout local.
"""
import os, sys, json, threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from parser import load_rules, parse_nql, QLError
from engine import analyze_text, analyze_path, score, LANG_MAP

PORT = int(os.environ.get('NEXUS_QL_PORT', 3620))
WORKSPACE = os.path.join(HERE, 'workspace')
BUILTIN = os.path.join(HERE, 'rules', 'builtin.nql')
os.makedirs(WORKSPACE, exist_ok=True)

_lock = threading.Lock()
def builtin_rules():
    with _lock:
        return load_rules(BUILTIN)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    # ── utilitaires ──
    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            return json.loads(self.rfile.read(n).decode() or '{}')
        except json.JSONDecodeError:
            return {}

    def _static(self, name):
        path = os.path.join(HERE, 'web', name)
        ctype = {'html':'text/html','js':'text/javascript','css':'text/css',
                 'svg':'image/svg+xml'}.get(os.path.splitext(name)[1][1:], 'text/plain')
        try:
            data = open(path, 'rb').read()
            self.send_response(200)
            self.send_header('Content-Type', f'{ctype}; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self.send_error(404)

    # ── GET ──
    def do_GET(self):
        route = self.path.split('?')[0]
        if route in ('/', '/index.html'):
            return self._static('index.html')
        if route.endswith(('.css', '.js', '.svg')):
            return self._static(os.path.basename(route))
        if route == '/api/status':
            return self._json({'nexusql': '3.0', 'port': PORT,
                               'regles': len(builtin_rules()),
                               'langues': len(LANG_MAP),
                               'workspace': WORKSPACE})
        if route == '/api/rules':
            return self._json([r.to_dict() for r in builtin_rules()])
        if route == '/api/files':
            files = sorted(f for f in os.listdir(WORKSPACE)
                           if os.path.splitext(f)[1].lower() in LANG_MAP)
            return self._json({'fichiers': files})
        if route == '/api/file':
            name = self.path.split('name=')[-1][:120]
            name = os.path.basename(name)  # anti-traversal
            try:
                code = open(os.path.join(WORKSPACE, name), encoding='utf-8', errors='replace').read()
                return self._json({'nom': name, 'code': code})
            except FileNotFoundError:
                return self._json({'erreur': 'fichier inconnu'}, 404)
        self._json({'erreur': 'route inconnue'}, 404)

    # ── POST ──
    def do_POST(self):
        route = self.path.split('?')[0]
        b = self._body()
        if route == '/api/analyze':
            rules = builtin_rules()
            if b.get('path'):
                reps = analyze_path(os.path.expanduser(b['path']), rules)
                findings = [f for r in reps for f in r['findings']]
                return self._json({'findings': findings,
                                   'score': score(findings),
                                   'fichiers': len(reps)})
            code, fname = b.get('code', ''), b.get('nom', 'snippet.py')
            findings = analyze_text(code, rules, fname, b.get('lang'))
            return self._json({'findings': findings, 'score': score(findings)})
        if route == '/api/query':
            try:
                rules = parse_nql(b.get('nql', ''))
            except QLError as e:
                return self._json({'erreur': str(e)}, 400)
            findings = analyze_text(b.get('code', ''), rules,
                                    b.get('nom', 'snippet.py'), b.get('lang'))
            return self._json({'findings': findings, 'score': score(findings)})
        if route == '/api/save':
            name = os.path.basename((b.get('nom') or 'sans-nom.py'))[:120]
            if os.path.splitext(name)[1].lower() not in LANG_MAP:
                return self._json({'erreur': 'extension non analysable'}, 400)
            with open(os.path.join(WORKSPACE, name), 'w', encoding='utf-8') as f:
                f.write(b.get('code', ''))
            return self._json({'ok': True, 'nom': name})
        self._json({'erreur': 'route inconnue'}, 404)

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

def main():
    srv = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    print(f"[NEXUS QL v3] serveur → http://localhost:{PORT}")
    print(f"[NEXUS QL v3] {len(builtin_rules())} règles · {len(LANG_MAP)} extensions · {WORKSPACE}")
    srv.serve_forever()

if __name__ == '__main__':
    main()
