#!/usr/bin/env bash
# ============================================================
#  nexus-ql.sh — NEXUS QL v3 — lanceur
#  Le langage de requête de sécurité, en français, sans cloud.
#
#  scan    analyse un fichier ou un dossier (règles builtin)
#  query   requête NQL ad-hoc sur une cible
#  rules   liste les règles chargées
#  check   valide un fichier .nql (sans l'exécuter)
#  explain explique une règle en français
#  serve   démarre le serveur + éditeur (localhost:3620)
#  open    ouvre l'éditeur dans Mozilla Firefox
#  stop    arrête le serveur
#  demo    scan du workspace de démonstration
#  install raccourci bureau (sans sudo)
# ============================================================
set -u
[ -z "${BASH_VERSION:-}" ] && exec bash "$0" "$@"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
PORT=3620
URL="http://localhost:${PORT}"

C_G='\033[1;32m'; C_R='\033[1;31m'; C_B='\033[1;34m'; C_Y='\033[1;33m'; C_V='\033[1;35m'; C_0='\033[0m'
banner() { echo -e "$C_V
  ╔══════════════════════════════════════════════════════╗
  ║   N E X U S   Q L   v 3 . 0                          ║
  ║   le langage de requête de sécurité · en français     ║
  ║   source → sink · 30 règles · 17 langages · sans cloud║
  ╚══════════════════════════════════════════════════════╝$C_0"; }

pid_of() { pgrep -f "python3.*$DIR/server.py" 2>/dev/null | head -1; }

serve() {
  # 1) déjà en ligne ? (test HTTP — fiable même si lancé d'ailleurs)
  if curl -s -m 1 "$URL/api/status" >/dev/null 2>&1; then
    echo -e "${C_Y}[!] serveur déjà en ligne → $URL${C_0}"; return 0
  fi
  # 2) un process fantôme sans le port ? on le nettoie proprement
  local p; p="$(pid_of)"
  [ -n "$p" ] && kill "$p" 2>/dev/null && sleep 0.5
  command -v python3 >/dev/null || { echo -e "${C_R}[✗] python3 requis${C_0}"; return 1; }
  nohup python3 "$DIR/server.py" > "$DIR/server.log" 2>&1 &
  for i in $(seq 1 20); do curl -s -m 1 "$URL/api/status" >/dev/null 2>&1 && break; sleep 0.3; done
  if curl -s -m 1 "$URL/api/status" >/dev/null 2>&1; then
    echo -e "${C_G}[✓] serveur NEXUS QL → $URL${C_0}  (log : $DIR/server.log)"
  else
    echo -e "${C_R}[✗] échec — voir $DIR/server.log${C_0}"; return 1
  fi
}

ouvre() {
  serve || return 1
  FF=""
  for B in firefox firefox-esr firefox-developer-edition; do
    command -v "$B" >/dev/null 2>&1 && FF="$B" && break
  done
  if [ -n "$FF" ]; then
    echo -e "${C_G}[✓] Mozilla Firefox → $URL${C_0}"
    case "${1:-}" in
      --onglet) nohup "$FF" --new-tab "$URL" >/dev/null 2>&1 & disown ;;
      --kiosk)  nohup "$FF" --kiosk "$URL" >/dev/null 2>&1 & disown ;;
      *)        nohup "$FF" --new-window "$URL" >/dev/null 2>&1 & disown ;;
    esac
  elif command -v xdg-open >/dev/null 2>&1; then
    echo "[+] Firefox introuvable — navigateur par défaut → $URL"
    nohup xdg-open "$URL" >/dev/null 2>&1 & disown
  else
    echo -e "${C_Y}[!] ouvre manuellement : $URL${C_0}"
  fi
}

install_desktop() {
  ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
  APP_DIR="$HOME/.local/share/applications"
  mkdir -p "$ICON_DIR" "$APP_DIR"
  cat > "$ICON_DIR/nexus-ql.svg" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#a78bfa"/>
  </linearGradient></defs>
  <rect width="64" height="64" rx="14" fill="#0b0b12"/>
  <path d="M14 50V14l36 36V14" stroke="url(#g)" stroke-width="9" fill="none"
    stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVG
  cat > "$APP_DIR/nexus-ql.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=NEXUS QL v3
Comment=Le langage de requête de sécurité — en français, sans cloud
Exec=${DIR}/nexus-ql.sh open
Icon=nexus-ql
Terminal=false
Categories=Development;Security;
DESK
  command -v update-desktop-database >/dev/null && update-desktop-database "$APP_DIR" 2>/dev/null
  echo -e "${C_G}[✓] raccourci bureau installé : NEXUS QL v3${C_0}"
}

case "${1:-}" in
  scan)    shift; [ -n "${1:-}" ] && python3 "$DIR/cli.py" scan "$@" || { echo "usage : $0 scan <fichier|dossier> [--json] [--nql f.nql]"; exit 1; } ;;
  query)   shift; [ $# -ge 2 ] && python3 "$DIR/cli.py" query "$@" || { echo "usage : $0 query '<requête NQL>' <cible>"; echo "  ex  : $0 query 'REGLE x GRAVITE critique DANS *.py MOTIF \"eval\\\\s*\\\\(\" QUAND TAINT' mon.py"; exit 1; } ;;
  rules)   shift; python3 "$DIR/cli.py" rules "${1:-}" ;;
  check)   shift; [ -n "${1:-}" ] && python3 "$DIR/cli.py" check "$1" || { echo "usage : $0 check <fichier.nql>"; exit 1; } ;;
  explain) shift; python3 "$DIR/cli.py" explain "${1:-}" ;;
  serve)   banner; serve ;;
  open)    banner; ouvre "${2:-}" ;;
  stop)    p=$(pid_of); [ -n "$p" ] && kill "$p" && echo "[+] serveur arrêté (pid $p)" || echo "[!] pas lancé" ;;
  restart) "$0" stop; sleep 1; "$0" serve ;;
  demo)    banner; bash "$0" scan "$DIR/workspace" ;;
  status)  curl -s -m 2 "$URL/api/status" | python3 -m json.tool 2>/dev/null || echo "[!] serveur arrêté — bash $0 serve" ;;
  install) install_desktop ;;
  *)
    banner
    echo -e "  ${C_Y}usage :${C_0} bash nexus-ql.sh <commande>

    ${C_G}scan${C_0}     analyse un fichier/dossier :  $0 scan ~/mes-projets
    ${C_G}query${C_0}    requête NQL ad-hoc (le vrai langage) :
               $0 query 'REGLE x GRAVITE critique DANS *.py MOTIF \"eval\\\\s*\\\\(\" QUAND TAINT' app.py
    ${C_G}rules${C_0}    les 30 règles chargées (avec explication simple)
    ${C_G}check${C_0}    valide TES règles :  $0 check mes-regles.nql
    ${C_G}explain${C_0}  une règle détaillée : $0 explain py-eval
    ${C_G}serve${C_0}    serveur + API :$PORT
    ${C_G}open${C_0}     l'éditeur dans Firefox (--onglet · --kiosk)
    ${C_G}demo${C_0}     scan du workspace de démo (5 fichiers piégés)
    ${C_G}stop${C_0} · ${C_G}status${C_0} · ${C_G}install${C_0}

  ${C_Y}le langage NQL (10 mots) :${C_0}
    REGLE id · GRAVITE critique|haute|moyenne|basse · DANS *.py…
    MOTIF \"regex du sink\" · SOURCE \"regex source\" · PROPRE \"sanitizer\"
    GARDE \"validation\" · QUAND TAINT|TOUJOURS · DIRE \"…\" · SIMPLEMENT \"…\"

  ${C_Y}ce que GitHub CodeQL fait avec le cloud, NEXUS QL le fait :${C_0}
    ${C_B}en local · en français · sans compte · sans envoyer ton code${C_0}
    et en plus il te donne le chemin complet de la donnée non fiable
    (source → propagation → sink) pour chaque constat."
    ;;
esac
