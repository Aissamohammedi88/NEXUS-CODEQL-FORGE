#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parser.py — NEXUS QL v3 — le parseur du langage NQL.

Le langage NQL (Nexus Query Language), en français :

    REGLE py-eval-dynamique
      GRAVITE  critique
      DANS     *.py, *.pyw
      MOTIF    "eval\\s*\\("
      SOURCE   "input\\(|request\\.|argv|stdin|environ|recv"
      PROPRE   "int\\(|sanitize|escape"
      QUAND    TAINT
      DIRE     "eval() exécute du code arbitraire."
      SIMPLEMENT "eval exécute tout ce qu'on lui donne."

Tout peut tenir sur une ligne aussi (requête ad-hoc) :
    REGLE x GRAVITE haute DANS *.py MOTIF "eval\\s*\\(" QUAND TAINT

Champs :
  REGLE      id unique (auto si absent)
  GRAVITE    critique | haute | moyenne | basse   (base de confiance 80/70/55/45)
  DANS       globs séparés par virgules
  MOTIF      regex = le SINK (l'opération dangereuse)
  SOURCE     regex = ce qui crée une donnée non fiable (active le taint tracking)
  PROPRE     regex = sanitizer (baisse la confiance)
  GARDE      regex = validation/borne (baisse un peu)
  QUAND      TAINT (exige un chemin source→sink) ou TOUJOURS (défaut)
  DIRE       explication technique
  SIMPLEMENT explication simple
"""
import re

KEYWORDS = ("REGLE", "GRAVITE", "DANS", "MOTIF", "SOURCE", "PROPRE",
            "GARDE", "QUAND", "DIRE", "SIMPLEMENT")
GRAVITE_BASE = {"critique": 80, "haute": 70, "moyenne": 55, "basse": 45}

class QLError(Exception):
    """erreur de syntaxe NQL, avec message lisible"""

class Rule:
    __slots__ = ("rid", "gravite", "globs", "motif", "source", "propre",
                 "garde", "quand", "dire", "simplement", "raw",
                 "rx_motif", "rx_source", "rx_propre", "rx_garde")
    def __init__(self):
        self.rid = None; self.gravite = "moyenne"; self.globs = []
        self.motif = None; self.source = None; self.propre = None
        self.garde = None; self.quand = "toujours"
        self.dire = ""; self.simplement = ""; self.raw = ""
    @property
    def base(self):
        return GRAVITE_BASE.get(self.gravite, 55)
    def to_dict(self):
        return {"id": self.rid, "gravite": self.gravite, "dans": self.globs,
                "motif": self.motif, "source": self.source, "propre": self.propre,
                "garde": self.garde, "quand": self.quand, "dire": self.dire,
                "simplement": self.simplement}

def _compile(rx, rid, champ):
    """compile une regex NQL, message d'erreur propre si elle est cassée"""
    if rx is None:
        return None
    try:
        return re.compile(rx, re.I)
    except re.error as e:
        raise QLError(f"[{rid}] {champ} : regex invalide ({e}) → {rx!r}")

def compile_rule(rule):
    """compile motif/source/propre/garde d'une Rule remplie"""
    if not rule.globs:
        raise QLError(f"[{rule.rid}] DANS manquant : il faut au moins un glob (ex : DANS *.py)")
    if not rule.motif:
        raise QLError(f"[{rule.rid}] MOTIF manquant : c'est le cœur de la requête (ex : MOTIF \"eval\\\\s*\\\\(\")")
    rule.rx_motif  = _compile(rule.motif,  rule.rid, "MOTIF")
    rule.rx_source = _compile(rule.source, rule.rid, "SOURCE")
    rule.rx_propre = _compile(rule.propre, rule.rid, "PROPRE")
    rule.rx_garde = _compile(rule.garde,  rule.rid, "GARDE")
    return rule

_TOKEN = re.compile(
    r'(REGLE|GRAVITE|DANS|MOTIF|SOURCE|PROPRE|GARDE|QUAND|DIRE|SIMPLEMENT)[ \t]*'
    r'([^\n]+?)(?=\s*(?:REGLE|GRAVITE|DANS|MOTIF|SOURCE|PROPRE|GARDE|QUAND|DIRE|SIMPLEMENT)\b|\s*\n|$)',
    re.S)

def _val(s):
    """déquote une valeur si elle est entre guillemets"""
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        return s[1:-1]
    return s

def parse_nql(text, start_id=1):
    """parse un texte NQL (plusieurs règles) → [Rule compilées]
    lève QLError avec un message français clair"""
    rules, errors = [], []
    blocks = re.split(r'(?m)^(?=\s*REGLE\b)', text)
    blocks = [b for b in blocks if b and re.search(r'\b(REGLE|GRAVITE|DANS|MOTIF)\b', b)]
    for b in blocks:
        r = Rule(); r.raw = b.strip()[:400]
        for m in _TOKEN.finditer(b):
            key, val = m.group(1), _val(m.group(2))
            if key == "REGLE":     r.rid = val
            elif key == "GRAVITE":
                g = val.lower().strip()
                if g not in GRAVITE_BASE:
                    errors.append(f"GRAVITE invalide : {val!r} (critique|haute|moyenne|basse)")
                r.gravite = g if g in GRAVITE_BASE else "moyenne"
            elif key == "DANS":    r.globs = [g.strip() for g in val.split(",") if g.strip()]
            elif key == "MOTIF":   r.motif = val
            elif key == "SOURCE":  r.source = val
            elif key == "PROPRE":  r.propre = val
            elif key == "GARDE":   r.garde = val
            elif key == "QUAND":
                q = val.upper().strip()
                if q not in ("TAINT", "TOUJOURS"):
                    errors.append(f"QUAND invalide : {val!r} (TAINT|TOUJOURS)")
                r.quand = "taint" if q == "TAINT" else "toujours"
            elif key == "DIRE":       r.dire = val
            elif key == "SIMPLEMENT": r.simplement = val
        if not r.rid:
            r.rid = f"regle-{start_id + len(rules)}"
        if errors:
            raise QLError(" · ".join(errors))
        rules.append(compile_rule(r))
    if not rules:
        raise QLError("aucune règle NQL trouvée (il faut au moins REGLE/GRAVITE/DANS/MOTIF)")
    return rules

def load_rules(path):
    """charge un fichier .nql"""
    with open(path, encoding="utf-8") as f:
        return parse_nql(f.read())

def glob_match(globs, filename):
    """un glob de la règle couvre-t-il ce fichier ? (*.py, *.ts, t.*)"""
    import fnmatch
    name = filename.replace("\\", "/").rsplit("/", 1)[-1].lower()
    return any(fnmatch.fnmatch(name, g.lower()) for g in globs)
