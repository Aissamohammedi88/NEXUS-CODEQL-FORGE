#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
engine.py — NEXUS QL v3 — le moteur d'exécution des requêtes NQL.

Deux étages :
  1. MATCH   : chaque ligne qui matche MOTIF (le sink) est candidate
  2. TAINT   : suivi de contamination intra-fichier
                 source (input/argv/...) ──propagation──▶ sink
              la donnée non fiable est suivie variable par variable,
              ligne après ligne → un CHEMIN complet est produit.

C'est le cœur de ce que fait CodeQL (GitHub) — en local, sans cloud,
sans base de données, et avec des explications en français.
"""
import os, re, hashlib, time
from parser import Rule, glob_match, parse_nql

LANG_MAP = {'.py':'python', '.pyw':'python', '.js':'javascript', '.ts':'typescript',
            '.jsx':'javascript', '.tsx':'typescript', '.mjs':'javascript',
            '.c':'c', '.h':'c', '.cpp':'cpp', '.cc':'cpp', '.cxx':'cpp', '.hpp':'cpp',
            '.go':'go', '.rs':'rust', '.java':'java', '.lua':'lua',
            '.sh':'bash', '.bash':'bash', '.php':'php', '.rb':'ruby',
            '.cs':'csharp', '.kt':'kotlin', '.f90':'fortran', '.f95':'fortran'}

_COMMENT = {  # début de commentaire ligne, par langage
    'python':'#', 'javascript':'//', 'typescript':'//', 'java':'//',
    'c':'//', 'cpp':'//', 'go':'//', 'rust':'//', 'php':'//',
    'ruby':'#', 'csharp':'//', 'kotlin':'//', 'bash':'#', 'lua':'--',
    'fortran':'!'}

SEUIL = 55  # en dessous : faux positif probable → non rapporté

# affectation générique multi-langages :  var = expr   |   Type var = expr
_ASSIGN = re.compile(r'(?:^|[^A-Za-z0-9_.])([A-Za-z_][A-Za-z0-9_]*)\s*[:=]=?\s*(.+?);?\s*$')

def _lang_of(path):
    return LANG_MAP.get(os.path.splitext(path)[1].lower())

def _strip_comment(line, lang):
    """retire le commentaire de fin de ligne (hors chaines "") — moins de FP"""
    c = _COMMENT.get(lang)
    if not c:
        return line
    out, q = [], None
    i = 0
    while i < len(line):
        ch = line[i]
        if q:                      # dans une chaine
            if ch == '\\':
                out.append(line[i:i+2]); i += 2; continue
            if ch == q:
                q = None
            out.append(ch)
        elif ch in ('"', "'"):
            q = ch; out.append(ch)
        elif line.startswith(c, i):
            break                   # le commentaire commence ici
        else:
            out.append(ch)
        i += 1
    return ''.join(out)

# ───────────────────────── TAINT TRACKING ─────────────────────────

def taint_track(lines, rx_source, sink_line_idx, rx_propre=None):
    """suit la contamination depuis les sources jusqu'à la ligne du sink.

    rx_propre (sanitizer) : une affectation qui le matche NE devient PAS
    contaminée — int(input()) nettoie la donnée, la chaîne s'arrête là.

    retourne (tainted_ids, path) où :
      tainted_ids = identifiants contaminés utilisés par le sink
      path        = [(no_ligne, var, cause)] du parcours source → sink
    """
    tainted = {}      # var → (ligne source, cause)
    order   = []      # ordre d'apparition (pour le chemin)

    def add(var, ln, cause):
        if var not in tainted:
            tainted[var] = (ln, cause)
            order.append(var)

    # 1) sources : var = <source>  |  utilisation directe de la source
    #    une affectation SANITIZÉE (int(input())) ne contamine PAS
    for i, raw in enumerate(lines):
        if rx_source.search(raw):
            if rx_propre and rx_propre.search(raw):
                continue          # la donnée est nettoyée avant affectation
            m = _ASSIGN.search(raw)
            if m and m.group(1) not in ('if', 'for', 'while', 'return', 'elif'):
                add(m.group(1), i + 1, 'reçoit la donnée non fiable')
    if not tainted:
        return [], []

    # 2) propagation en 3 passes : var2 = f(var1 contaminé)
    #    (sauf si l'affectation est sanitizée)
    for _ in range(3):
        for i, raw in enumerate(lines):
            m = _ASSIGN.search(raw)
            if not m:
                continue
            dst, expr = m.group(1), m.group(2)
            if dst in ('if', 'for', 'while', 'return', 'elif', 'else'):
                continue
            if rx_propre and rx_propre.search(raw):
                continue          # int(var) → dst propre
            for var in list(tainted):
                if var != dst and re.search(r'\b' + re.escape(var) + r'\b', expr):
                    add(dst, i + 1, f'propage « {var} »')
                    break

    # 3) le sink utilise-t-il une variable contaminée ?
    sink_line = lines[sink_line_idx]
    used = [v for v in order if re.search(r'\b' + re.escape(v) + r'\b', sink_line)]
    if not used:
        # source utilisée DIRECTEMENT dans le sink (eval(input()))
        if rx_source.search(sink_line):
            return ['(direct)'], [(sink_line_idx + 1, '(source directe)', 'donnée non fiable dans le sink')]
        return [], []

    # 4) reconstruction du chemin complet
    path, seen = [], set()
    for v in order:
        if v not in tainted:
            continue
        ln, cause = tainted[v]
        if (v, ln) in seen:
            continue
        seen.add((v, ln))
        path.append((ln, v, cause))
    return used, path

# ───────────────────────── MOTEUR ─────────────────────────

def analyze_text(text, rules, filename='input', lang=None):
    """exécute les règles NQL sur un texte → findings"""
    lang = lang or _lang_of(filename) or 'unknown'
    lines = text.split('\n')
    clean = [_strip_comment(l, lang) for l in lines]
    findings = []
    for r in rules:
        if not glob_match(r.globs, filename) and lang != 'unknown':
            continue
        for i, line in enumerate(clean):
            if not line.strip():
                continue
            m = r.rx_motif.search(line)
            if not m:
                continue
            conf = r.base
            # ── taint tracking ──
            used, path = [], []
            if r.rx_source:
                used, path = taint_track(clean, r.rx_source, i, r.rx_propre)
            if r.quand == 'taint':
                if used:
                    conf += 15            # chemin complet prouvé
                else:
                    conf -= 40            # aucune donnée non fiable → FP probable
            elif used:
                conf += 8                 # bonus indicatif
            # ── sanitizers / gardes (fenêtre sink ± 4 lignes) ──
            window = '\n'.join(clean[max(0, i-4):i+5])
            if r.rx_propre and r.rx_propre.search(line):
                conf -= 30
            if r.rx_garde and r.rx_garde.search(window):
                conf -= 15
            conf = max(5, min(99, round(conf)))
            if conf < SEUIL:
                continue
            findings.append({
                'regle': r.rid, 'gravite': r.gravite, 'confiance': conf,
                'fichier': filename, 'ligne': i + 1,
                'colonne': (m.start() + 1) if m else 1,
                'extrait': lines[i].strip()[:160],
                'dire': r.dire or f"correspondance de la règle {r.rid}",
                'simplement': r.simplement or '',
                'taint': path,                 # le chemin source → sink
            })
    return findings

def analyze_file(path, rules):
    lang = _lang_of(path)
    if not lang:
        return {'lang': None, 'findings': [], 'fichier': path}
    with open(path, 'r', errors='replace') as f:
        text = f.read()
    return {'lang': lang, 'fichier': path,
            'findings': analyze_text(text, rules, os.path.basename(path), lang)}

def analyze_path(path, rules):
    """fichier OU dossier → rapport multi-fichiers"""
    if os.path.isfile(path):
        rep = analyze_file(path, rules)
        rep['score'] = score(rep['findings'])
        return [rep]
    out = []
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '__pycache__', 'venv', '.venv')]
        for f in sorted(files):
            if _lang_of(f):
                out.append(analyze_file(os.path.join(root, f), rules))
    for rep in out:
        rep['score'] = score(rep['findings'])
    return out

def score(findings):
    w = {'critique': 40, 'haute': 25, 'moyenne': 12, 'basse': 5}
    penalty = sum(w.get(f['gravite'], 5) * f['confiance'] / 100 for f in findings)
    return max(0, round(100 - min(100, penalty)))

def findings_json(path, rules):
    reps = analyze_path(path, rules)
    return {
        'nexusql': '3.0',
        'cible': path,
        'fichiers': len(reps),
        'total': sum(len(r['findings']) for r in reps),
        'score_global': score([f for r in reps for f in r['findings']]),
        'analyses': [{k: v for k, v in r.items()} for r in reps if r['findings']] or reps[:1],
        'horodatage': time.strftime('%Y-%m-%d %H:%M:%S'),
    }

# ── CLI interne (utilisé par nexus-ql.sh) ──
if __name__ == '__main__':
    import sys, json
    HERE = os.path.dirname(os.path.abspath(__file__))
    BUILTIN = os.path.join(HERE, 'rules', 'builtin.nql')
    args = sys.argv[1:]
    if not args:
        print("usage: engine.py <fichier|dossier> [fichier.nql]"); sys.exit(1)
    rules = load_rules(args[1] if len(args) > 1 else BUILTIN)
    print(json.dumps(findings_json(args[0], rules), indent=2, ensure_ascii=False))
