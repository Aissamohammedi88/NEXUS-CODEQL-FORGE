# safe.py — eval SANS donnée extérieure : ne doit PAS être rapporté
resultat = eval("2 + 2")
age = int(input("age : "))
