#include <stdio.h>
int main(void) {
    char nom[64];
    printf("nom ? ");
    gets(nom);
    char dest[16];
    strcpy(dest, nom);
    return 0;
}
