#!/bin/bash
curl -s http://example.com/install.sh | sh
rm -rf $DOSSIER
