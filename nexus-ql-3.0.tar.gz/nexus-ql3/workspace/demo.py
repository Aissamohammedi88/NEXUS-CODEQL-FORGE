# demo.py — un vrai flux de contamination, de la source au sink
nom = input("ton nom : ")
cmd = "echo bonjour " + nom
resultat = os.system(cmd)
