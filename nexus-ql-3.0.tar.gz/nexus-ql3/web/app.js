// NEXUS QL v3 — éditeur + requêtes ad-hoc, tout local sur :3620
"use strict";
const $ = (id) => document.getElementById(id);
const API = window.location.origin;

// ── démarrage : statut + fichiers du workspace ──
(async () => {
  try {
    const st = await (await fetch(`${API}/api/status`)).json();
    $(`badge-regles`).textContent = `${st.regles} règles · ${st.langues} extensions`;
    const rep = await (await fetch(`${API}/api/files`)).json();
    remplirFichiers(rep.fichiers || []);
    if ((rep.fichiers || []).length) chargerFichier(rep.fichiers[0]);
  } catch (e) {
    $(`verdict-txt`).textContent = "serveur injoignable — relance nexus-ql.sh serve";
  }
})();

function remplirFichiers(fs) {
  const sel = $(`sel-fichier`);
  sel.innerHTML = "";
  fs.forEach((f) => {
    const o = document.createElement("option");
    o.value = o.textContent = f;
    sel.appendChild(o);
  });
}
async function chargerFichier(nom) {
  try {
    const r = await (await fetch(`${API}/api/file?name=${encodeURIComponent(nom)}`)).json();
    $(`code`).value = r.code; $(`inp-nom`).value = r.nom;
    gouttiere();
  } catch (e) { /* silencieux */ }
}
$(`sel-fichier`).addEventListener("change", (e) => chargerFichier(e.target.value));

// ── gouttière avec numéros de ligne ──
function gouttiere(taintLines = new Set()) {
  const n = $(`code`).value.split("\n").length;
  let html = "";
  for (let i = 1; i <= n; i++)
    html += `<div class="${taintLines.has(i) ? "taint" : ""}">${i}</div>`;
  $(`gutter`).innerHTML = html;
  // synchronise le scroll
  $(`gutter`).style.height = $(`code`).clientHeight + "px";
}
$(`code`).addEventListener("scroll", () => {
  $(`gutter`).scrollTop = $(`code`).scrollTop;
});
$(`code`).addEventListener("input", () => gouttiere());
gouttiere();

// ── analyse ──
$(`btn-analyser`).addEventListener("click", async () => {
  const body = { code: $(`code`).value, nom: $(`inp-nom`).value || "snippet.py" };
  const r = await fetch(`${API}/api/analyze`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const rep = await r.json();
  affiche(rep, false);
});

// ── requête NQL ad-hoc ──
$(`btn-requete`).addEventListener("click", async () => {
  $(`nql-erreur`).textContent = "";
  const body = { nql: $(`nql`).value, code: $(`code`).value,
                 nom: $(`inp-nom`).value || "snippet.py" };
  const r = await fetch(`${API}/api/query`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const rep = await r.json();
  if (!r.ok) { $(`nql-erreur`).textContent = rep.erreur || "requête invalide"; return; }
  affiche(rep, true);
});

// ── sauvegarde dans le workspace ──
$(`btn-sauver`).addEventListener("click", async () => {
  const body = { nom: $(`inp-nom`).value || "snippet.py", code: $(`code`).value };
  const r = await fetch(`${API}/api/save`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const rep = await r.json();
  if (!r.ok) { $(`verdict-txt`).textContent = rep.erreur; return; }
  $(`verdict-txt`).textContent = `sauvé → workspace/${rep.nom}`;
  const liste = await (await fetch(`${API}/api/files`)).json();
  remplirFichiers(liste.fichiers || []);
});

// ── rendu des constats ──
function affiche(rep, adhoc) {
  const res = $(`resultats`);
  res.classList.remove("vides");
  res.innerHTML = "";
  const fs = rep.findings || [];
  // verdict
  const s = rep.score ?? 100;
  $(`score`).textContent = s + "/100";
  $(`score`).style.color = s >= 85 ? "#34d399" : s >= 60 ? "#fbbf24" : "#f87171";
  $(`verdict-txt`).textContent =
    (adhoc ? "requête ad-hoc · " : "") +
    (fs.length === 0 ? "rien à signaler au-dessus du seuil de confiance"
                     : `${fs.length} constat(s) — clique pour voir la ligne`);

  // lignes taintées (pour la gouttière)
  const taintLines = new Set();
  fs.forEach((f) => (f.taint || []).forEach(([ln]) => taintLines.add(ln)));
  gouttiere(taintLines);

  if (fs.length === 0) {
    res.innerHTML = `<p class="hint">aucun constat — le code est propre au seuil de confiance 55.</p>`;
    return;
  }
  fs.forEach((f) => {
    const d = document.createElement("div");
    d.className = "constat";
    let chemin = "";
    if (f.taint && f.taint.length) {
      chemin = `<div class="chemin"><b>chemin de la donnée :</b> ` +
        f.taint.map(([ln, v, c]) =>
          `<span class="etape">L${ln} ${esc(v)}</span> <span class="fleche">→</span>`).join(" ") +
        ` <span class="etape">L${f.ligne} sink</span></div>`;
    }
    d.innerHTML = `
      <div class="ligne1">
        <span class="grav ${f.gravite}">${f.gravite.toUpperCase()}</span>
        <span class="regle-id">${esc(f.regle)}</span>
        <span>L${f.ligne}</span>
        <span class="conf">confiance ${f.confiance}%</span>
      </div>
      <div class="extrait">${esc(f.extrait || "")}</div>
      ${f.simplement ? `<div class="simple">${esc(f.simplement)}</div>` : ""}
      ${chemin}`;
    d.addEventListener("click", () => {
      const ta = $(`code`);
      const lignes = ta.value.split("\n");
      ta.focus();
      ta.selectionStart = ta.selectionEnd =
        lignes.slice(0, f.ligne - 1).join("\n").length + (f.ligne > 1 ? 1 : 0);
      // scrolle la textarea vers la ligne
      ta.scrollTop = Math.max(0, (f.ligne - 4) * 19.2);
      $(`gutter`).scrollTop = ta.scrollTop;
    });
    res.appendChild(d);
  });
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// lien API rules
$(`lnk-rules`).addEventListener("click", async () => {
  const r = await (await fetch(`${API}/api/rules`)).json();
  $(`nql-erreur`).style.color = "#71718f";
  $(`nql-erreur`).textContent =
    `${r.length} règles : ` + r.map((x) => x.id).join(", ");
});
