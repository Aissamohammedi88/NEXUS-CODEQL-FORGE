# NEXUS QL v3 — le langage de requête de sécurité

**En français. Sans cloud. Sans compte. Ton code ne quitte jamais ta machine.**

Ce que GitHub CodeQL fait avec le cloud et une base de données de plusieurs
gigaoctets, NEXUS QL v3 le fait en local : un vrai **langage de requête**
(le NQL), un **suivi de contamination source → sink** avec le chemin complet,
des explications en français simple. Python 3 suffit.

```
bash nexus-ql.sh open      # l'éditeur dans Firefox (localhost:3620)
bash nexus-ql.sh demo      # scan des 6 fichiers de démonstration
bash nexus-ql.sh scan ~/mes-projets
```

## Le langage NQL — 10 mots, c'est tout

```
REGLE mon-eval-perso
  GRAVITE  critique                       # critique | haute | moyenne | basse
  DANS     *.py                           # les fichiers visés (globs à virgules)
  MOTIF    "eval\s*\("                    # le SINK : l'opération dangereuse
  SOURCE   "input\(|request\.|argv"       # la SOURCE : donnée non fiable
  PROPRE   "int\(|sanitize"               # sanitizer : la confiance baisse
  GARDE    "len\(|snprintf"               # validation : la confiance baisse un peu
  QUAND    TAINT                          # TAINT : chemin obligatoire | TOUJOURS
  DIRE     "eval() exécute du code arbitraire."
  SIMPLEMENT "eval exécute tout ce qu'on lui donne."
```

Sauvée dans `mes-regles.nql`, lancée :

```
bash nexus-ql.sh scan mon-projet --nql mes-regles.nql
```

Ou en une ligne (requête ad-hoc) :

```
bash nexus-ql.sh query 'REGLE x GRAVITE critique DANS *.py MOTIF "eval\s*\(" QUAND TAINT' app.py
```

## Le suivi de contamination (source → sink)

Le cœur de la v3 — ce que la v2 ne faisait pas : la donnée non fiable est
**suivie variable par variable, ligne après ligne**, jusqu'au sink :

```
L2  nom = input("ton nom : ")         ← la donnée entre
L3  cmd = "echo bonjour " + nom       ← elle se propage
L4  os.system(cmd)                    ← le sink — TROUVÉ, confiance 95 %

chemin : L2 nom (reçoit la donnée non fiable) → L3 cmd (propage nom) → L4 sink
```

Et l'inverse — un `eval("2 + 2")` sans donnée extérieure **n'est pas
rapporté** ; un `age = int(input())` **stoppe** la contamination (donnée
nettoyée). Moins de faux positifs = des alarmes dans lesquelles tu peux
avoir confiance.

## Commandes

| commande | effet |
|---|---|
| `scan <cible>` | analyse un fichier ou un dossier (règles builtin, 30) |
| `query '<NQL>' <cible>` | requête ad-hoc en une ligne |
| `rules` | liste les règles avec leur explication simple |
| `check <fichier.nql>` | valide TES règles sans les exécuter |
| `explain <id>` | une règle détaillée (sink, source, sanitizer) |
| `serve` / `open` / `stop` | serveur local :3620, éditeur Firefox |
| `demo` | scan du workspace de démonstration |
| `install` | raccourci bureau (sans sudo) |

`--json` sur `scan` et `query` : sortie machine (`score_global`,
`analyses[]`, `findings[]` avec `taint` = le chemin) pour brancher dans
une CI.

## L'éditeur (localhost:3620)

Colle du code → **Analyser** → les constats à droite, avec gravité,
confiance, explication simple et le **chemin de la donnée** ; un clic
amène à la ligne. La console du bas exécute des requêtes NQL ad-hoc
directement sur le code affiché.

## Règles embarquées (30) · 17 langages

Python, JavaScript, TypeScript, C, C++, Go, Rust, Java, Lua, Bash,
PHP, Ruby, C#, Kotlin, Fortran… (`rules/builtin.nql` — copie-le,
modifie-le, il est à toi : c'est un fichier NQL.)

## Zéro dépendance

Python 3 et sa bibliothèque standard uniquement (`re`, `os`, `http.server`).
Pas de paquet à installer, pas de réseau sortant, rien n'est envoyé.
