#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cli.py — NEXUS QL v3 — l'interface en ligne de commande.

    cli.py scan   <fichier|dossier> [--json] [--nql <fichier.nql>]
    cli.py query  '<requête NQL>' <fichier|dossier> [--json]
    cli.py rules  [<fichier.nql>]
    cli.py check  <fichier.nql>        (valide la syntaxe, sans exécuter)
    cli.py explain <id-de-règle>       (la règle expliquée en français)
"""
import sys, os, json, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from parser import load_rules, parse_nql, QLError
from engine import analyze_path, findings_json, score

BUILTIN = os.path.join(HERE, 'rules', 'builtin.nql')

# couleurs (désactivées si pas un tty)
_TTY = sys.stdout.isatty()
def C(code, s):
    return f"\033[{code}m{s}\033[0m" if _TTY else str(s)
ROUGE, ORANGE, JAUNE, VERT, BLEU, VIOLET = "1;31", "1;33", "1;33", "1;32", "1;34", "1;35"

GRAV_C = {'critique': ROUGE, 'haute': ORANGE, 'moyenne': JAUNE, 'basse': "0;37"}

def _rules_or_die(path_nql):
    try:
        return load_rules(path_nql)
    except QLError as e:
        print(C(ROUGE, f"[✗] règle NQL invalide : {e}")); sys.exit(2)
    except FileNotFoundError:
        print(C(ROUGE, f"[✗] fichier introuvable : {path_nql}")); sys.exit(2)

def cmd_rules(args):
    rules = _rules_or_die(args.nql or BUILTIN)
    print(C(VIOLET, f"  NEXUS QL v3 — {len(rules)} règles chargées") + f"  ({args.nql or 'rules/builtin.nql'})\n")
    for r in rules:
        print(f"  {C(GRAV_C.get(r.gravite, '0'), r.rid):32s} {r.gravite:9s} "
              f"{','.join(r.globs):28s} {'TAINT' if r.quand == 'taint' else '     '}")
        if r.simplement:
            print(f"      {r.simplement}")
    return 0

def cmd_check(args):
    try:
        rules = load_rules(args.nql)
        print(C(VERT, f"[✓] {len(rules)} règle(s) NQL valide(s) :"))
        for r in rules:
            print(f"    {r.rid} — gravite {r.gravite}, sink {r.motif[:40]}")
        return 0
    except QLError as e:
        print(C(ROUGE, f"[✗] syntaxe NQL : {e}")); return 2
    except FileNotFoundError:
        print(C(ROUGE, f"[✗] fichier introuvable : {args.nql}")); return 2

def cmd_explain(args):
    rules = _rules_or_die(BUILTIN)
    for r in rules:
        if r.rid == args.regle:
            print(C(VIOLET, f"RÈGLE {r.rid}"))
            print(f"  gravité   : {r.gravite} (confiance de base {r.base})")
            print(f"  fichiers  : {', '.join(r.globs)}")
            print(f"  sink      : {r.motif}")
            if r.source: print(f"  source    : {r.source}")
            if r.propre: print(f"  sanitizer : {r.propre}")
            if r.garde: print(f"  garde     : {r.garde}")
            print(f"  exigence  : {'chemin source→sink OBLIGATOIRE' if r.quand == 'taint' else 'toujours signalé'}")
            if r.dire:       print(f"\n  {r.dire}")
            if r.simplement: print(f"\n  {C(JAUNE, 'simplement :')} {r.simplement}")
            return 0
    print(C(ROUGE, f"[✗] règle inconnue : {args.regle} — lance 'rules' pour la liste"))
    return 2

def _print_report(reps, cible):
    total = sum(len(r['findings']) for r in reps)
    glob_score = score([f for r in reps for f in r['findings']])
    lamp = C(VERT, "SAIN ✓") if glob_score >= 85 else \
           C(JAUNE, "À SURVEILLER ⚠") if glob_score >= 60 else C(ROUGE, "DANGEREUX ✗")
    print(C(VIOLET, f"  NEXUS QL v3 — rapport pour {cible}"))
    print(f"  fichiers analysés : {len(reps)} · constats : {total} · score : {glob_score}/100 {lamp}\n")
    for rep in reps:
        if not rep['findings']:
            continue
        print(f"  {C(BLEU, rep['fichier'])}  [{rep['lang']}]  score {rep.get('score','-')}/100")
        for f in rep['findings']:
            g = C(GRAV_C.get(f['gravite'], '0'), f['gravite'].upper())
            print(f"    L{f['ligne']:<4} {g:9s} {f['regle']:14s} confiance {f['confiance']}%")
            print(f"          {f['extrait'][:100]}")
            if f['simplement']:
                print(f"          {C(JAUNE, '→')} {f['simplement']}")
            for (ln, var, cause) in f['taint']:
                print(f"          {C(VIOLET, 'chemin')} L{ln} {var} — {cause}")
        print()
    if total == 0:
        print(C(VERT, "  aucun constat au-dessus du seuil de confiance (55) — rien à signaler."))
    return 0

def cmd_scan(args):
    rules = _rules_or_die(args.nql or BUILTIN)
    if args.json:
        print(json.dumps(findings_json(args.cible, rules), indent=2, ensure_ascii=False))
        return 0
    reps = analyze_path(args.cible, rules)
    return _print_report(reps, args.cible)

def cmd_query(args):
    try:
        rules = parse_nql(args.nql_text)
    except QLError as e:
        print(C(ROUGE, f"[✗] requête NQL invalide : {e}")); return 2
    if args.json:
        print(json.dumps(findings_json(args.cible, rules), indent=2, ensure_ascii=False))
        return 0
    reps = analyze_path(args.cible, rules)
    print(C(VIOLET, f"  requête ad-hoc : {args.nql_text[:80]}"))
    return _print_report(reps, args.cible)

def main():
    p = argparse.ArgumentParser(prog='nexus-ql', description='NEXUS QL v3 — le langage de requête de sécurité, en français, sans cloud')
    sub = p.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('scan', help='analyse un fichier ou un dossier')
    s.add_argument('cible'); s.add_argument('--nql'); s.add_argument('--json', action='store_true')
    s.set_defaults(fn=cmd_scan)
    q = sub.add_parser('query', help='requête NQL ad-hoc (une ligne)')
    q.add_argument('nql_text'); q.add_argument('cible'); q.add_argument('--json', action='store_true')
    q.set_defaults(fn=cmd_query)
    r = sub.add_parser('rules', help='liste les règles chargées')
    r.add_argument('nql', nargs='?'); r.set_defaults(fn=cmd_rules)
    c = sub.add_parser('check', help='valide un fichier .nql')
    c.add_argument('nql'); c.set_defaults(fn=cmd_check)
    e = sub.add_parser('explain', help='explique une règle')
    e.add_argument('regle'); e.set_defaults(fn=cmd_explain)
    args = p.parse_args()
    sys.exit(args.fn(args))

if __name__ == '__main__':
    main()
